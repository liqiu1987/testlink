/* 
$Revision: 1.1 $
$Date: 2008/01/02 18:56:05 $
$Author: franciscom $
$Name:  $
*/
INSERT INTO db_version (version,notes,upgrade_ts) VALUES('DB 1.2', 'first version with API feature',CURRENT_TIMESTAMP());