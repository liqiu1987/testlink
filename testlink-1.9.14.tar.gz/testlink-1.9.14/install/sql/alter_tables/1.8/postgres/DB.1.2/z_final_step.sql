/* 
$Revision: 1.2 $
$Date: 2009/05/08 06:46:15 $
$Author: franciscom $
$Name:  $
*/
INSERT INTO "db_version" ("version","upgrade_ts","notes") VALUES ('DB 1.3',now(),'');